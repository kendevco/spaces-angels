"use client"

import { useState, useEffect } from "react"
import { SpaceSidebar } from "./components/space-sidebar"
import { ChatArea } from "./components/chat-area"
import { useIsMobile } from "./hooks/use-mobile"
import { cn } from "@/lib/utils"

export default function SpacesInterface() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const isMobile = useIsMobile()

  // Auto-collapse sidebar on mobile
  useEffect(() => {
    if (isMobile) {
      setIsSidebarCollapsed(true)
    }
  }, [isMobile])

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  return (
    <div className="flex h-screen bg-[#1e2124] text-white overflow-hidden">
      {/* Space Sidebar - Hidden on mobile when collapsed */}
      <SpaceSidebar
        isCollapsed={isSidebarCollapsed}
        onToggle={toggleSidebar}
        className={cn("transition-all duration-300 ease-in-out", isMobile && isSidebarCollapsed && "hidden")}
      />

      {/* Mobile Overlay */}
      {isMobile && !isSidebarCollapsed && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Chat Area */}
      <ChatArea isSidebarCollapsed={isSidebarCollapsed} onToggleSidebar={toggleSidebar} className="flex-1 min-w-0" />
    </div>
  )
}
