"use client"

import { useState } from "react"
import { RotateCcw, ChevronDown, ChevronUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ConnectionStatusProps {
  isConnected: boolean
  onReconnect: () => void
  className?: string
}

export function ConnectionStatus({ isConnected, onReconnect, className }: ConnectionStatusProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      {/* Mobile View - Compact */}
      <div className="md:hidden flex items-center space-x-2">
        <div className={cn("w-2 h-2 rounded-full", isConnected ? "bg-green-500" : "bg-red-500")}></div>
        {!isConnected && (
          <Button variant="ghost" size="sm" onClick={onReconnect} className="text-xs text-gray-400 hover:text-white">
            Reconnect
          </Button>
        )}
      </div>

      {/* Desktop View - Expandable */}
      <div className="hidden md:flex items-center space-x-2">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="flex items-center space-x-2 hover:bg-[#393c43] rounded px-2 py-1 transition-colors"
        >
          <div className={cn("w-2 h-2 rounded-full", isConnected ? "bg-green-500" : "bg-red-500")}></div>
          <span className={cn("text-sm", isConnected ? "text-green-400" : "text-red-400")}>
            {isConnected ? "Connected" : "Disconnected"}
          </span>
          {isExpanded ? (
            <ChevronUp className="w-3 h-3 text-gray-400" />
          ) : (
            <ChevronDown className="w-3 h-3 text-gray-400" />
          )}
        </button>

        {isExpanded && (
          <div className="flex items-center space-x-2 text-sm text-gray-400">
            {isConnected ? (
              <span>All systems operational</span>
            ) : (
              <>
                <span>Connection lost. Reconnecting...</span>
                <Button variant="ghost" size="sm" onClick={onReconnect} className="text-gray-400 hover:text-white">
                  <RotateCcw className="w-4 h-4 mr-1" />
                  Retry
                </Button>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
