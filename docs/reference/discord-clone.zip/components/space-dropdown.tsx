"use client"

import { Settings, Users, Send, Plus, Trash2, ChevronDown } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

interface SpaceDropdownProps {
  spaceName: string
  spaceAvatar?: string
  spaceInitials: string
  onSpaceSettings: () => void
  onManageMembers: () => void
  onSendInvitation: () => void
  onCreateChannel: () => void
  onDeleteSpace: () => void
}

export function SpaceDropdown({
  spaceName,
  spaceAvatar,
  spaceInitials,
  onSpaceSettings,
  onManageMembers,
  onSendInvitation,
  onCreateChannel,
  onDeleteSpace,
}: SpaceDropdownProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="w-full justify-between p-3 h-auto hover:bg-[#393c43] pr-10">
          <div className="flex items-center space-x-2">
            <Avatar className="w-8 h-8">
              <AvatarImage src={spaceAvatar || "/placeholder.svg"} />
              <AvatarFallback className="bg-[#5865f2] text-white text-xs">{spaceInitials}</AvatarFallback>
            </Avatar>
            <span className="font-semibold text-white truncate">{spaceName}</span>
          </div>
          <ChevronDown className="w-4 h-4 text-gray-400" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56 bg-[#18191c] border-[#202225] text-white" align="start">
        <DropdownMenuItem onClick={onSpaceSettings} className="focus:bg-[#393c43] focus:text-white cursor-pointer">
          <Settings className="w-4 h-4 mr-2" />
          Space Settings
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onManageMembers} className="focus:bg-[#393c43] focus:text-white cursor-pointer">
          <Users className="w-4 h-4 mr-2" />
          Manage Members
        </DropdownMenuItem>
        <DropdownMenuItem onClick={onSendInvitation} className="focus:bg-[#393c43] focus:text-white cursor-pointer">
          <Send className="w-4 h-4 mr-2" />
          Send Invitation
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-[#202225]" />
        <DropdownMenuItem onClick={onCreateChannel} className="focus:bg-[#393c43] focus:text-white cursor-pointer">
          <Plus className="w-4 h-4 mr-2" />
          Create Channel
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-[#202225]" />
        <DropdownMenuItem
          onClick={onDeleteSpace}
          className="focus:bg-red-600 focus:text-white cursor-pointer text-red-400"
        >
          <Trash2 className="w-4 h-4 mr-2" />
          Delete Space
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
