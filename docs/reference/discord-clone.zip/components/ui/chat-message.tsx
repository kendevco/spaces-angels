"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface ChatMessageProps {
  user: {
    name: string
    avatar?: string
    initials: string
    color: string
  }
  content: string
  timestamp: string
  isExpandable?: boolean
  onExpand?: () => void
  className?: string
}

export function ChatMessage({ user, content, timestamp, isExpandable, onExpand, className }: ChatMessageProps) {
  return (
    <div className={cn("flex space-x-3", className)}>
      <Avatar className="w-10 h-10 mt-1">
        <AvatarImage src={user.avatar || "/placeholder.svg?height=40&width=40"} />
        <AvatarFallback className={`${user.color} text-white`}>{user.initials}</AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <div className="flex items-center space-x-2 mb-1">
          <span className="font-semibold text-white">{user.name}</span>
          <span className="text-xs text-gray-400">{timestamp}</span>
        </div>
        <div className="text-gray-300 whitespace-pre-wrap">
          {content}
          {isExpandable && (
            <button
              onClick={onExpand}
              className="flex items-center space-x-2 text-gray-400 hover:text-white text-sm mt-2"
            >
              <span>Show More (43 more sections)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
