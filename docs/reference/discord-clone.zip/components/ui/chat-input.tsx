"use client"

import { useState, type KeyboardEvent } from "react"
import { Send, PlusCircle, Gift, Smile } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

interface ChatInputProps {
  placeholder?: string
  onSubmit?: (message: string) => void
  className?: string
}

export function ChatInput({ placeholder, onSubmit, className }: ChatInputProps) {
  const [message, setMessage] = useState("")

  const handleSubmit = () => {
    if (message.trim() && onSubmit) {
      onSubmit(message.trim())
      setMessage("")
    }
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <div className={cn("flex items-center space-x-3 bg-[#40444b] rounded-lg px-4 py-3", className)}>
      <Button variant="ghost" size="sm" className="w-6 h-6 p-0 hover:bg-[#393c43]">
        <PlusCircle className="w-5 h-5 text-gray-400 hover:text-white" />
      </Button>
      <Input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className="flex-1 bg-transparent border-none text-white placeholder-gray-400 focus:ring-0 focus:border-none focus-visible:ring-0 focus-visible:ring-offset-0"
      />
      <div className="flex items-center space-x-2">
        <Button variant="ghost" size="sm" className="w-6 h-6 p-0 hover:bg-[#393c43]">
          <Gift className="w-5 h-5 text-gray-400 hover:text-white" />
        </Button>
        <Button variant="ghost" size="sm" className="w-6 h-6 p-0 hover:bg-[#393c43]">
          <Smile className="w-5 h-5 text-gray-400 hover:text-white" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="w-6 h-6 p-0 hover:bg-[#393c43]"
          onClick={handleSubmit}
          disabled={!message.trim()}
        >
          <Send className="w-5 h-5 text-gray-400 hover:text-white" />
        </Button>
      </div>
    </div>
  )
}
