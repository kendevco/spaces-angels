"use client"

import { useState, useEffect, useRef } from "react"
import { Hash, Menu, Video, Users, Mic } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { ChatInput } from "@/components/ui/chat-input"
import { BusinessMessageCard } from "./business-message"
import { InfiniteScroll } from "@/components/ui/infinite-scroll"
import { cn } from "@/lib/utils"
import { ConnectionStatus } from "./connection-status"
import type { BusinessMessage as BusinessMessageType } from "../types/business"

interface BusinessChatAreaProps {
  isSidebarCollapsed: boolean
  onToggleSidebar: () => void
  className?: string
}

const initialMessages: BusinessMessageType[] = [
  {
    id: "1",
    user: {
      id: "1",
      name: "Sarah Chen",
      role: "Owner",
      status: "online",
      hasGuardianAngel: true,
    },
    content:
      "Good morning team! Let's review today's priorities. I see we have several high-value customers in the pipeline.",
    timestamp: "Today at 9:15 AM",
    type: "text",
  },
  {
    id: "2",
    user: {
      id: "2",
      name: "Leo Assistant",
      role: "Admin",
      status: "online",
      hasGuardianAngel: true,
    },
    content:
      "I've identified 3 customers ready for conversion to premium plans. Total potential revenue: $15,750. Should I initiate the upgrade sequence?",
    timestamp: "Today at 9:16 AM",
    type: "guardian",
  },
  {
    id: "3",
    user: {
      id: "3",
      name: "Mike Rodriguez",
      role: "Admin",
      status: "online",
      hasGuardianAngel: true,
    },
    content: "Payment request for Order #ORD-2024-001 is ready for approval.",
    timestamp: "Today at 9:18 AM",
    type: "payment",
    businessContext: {
      orderId: "ORD-2024-001",
      amount: 2450,
      status: "pending",
    },
  },
  {
    id: "4",
    user: {
      id: "4",
      name: "Emma Wilson",
      role: "Staff",
      status: "away",
      hasGuardianAngel: false,
    },
    content: "Contract signature needed for the Johnson account. Documents are prepared and ready.",
    timestamp: "Today at 9:20 AM",
    type: "signature",
    businessContext: {
      orderId: "CONTRACT-2024-015",
      status: "awaiting_signature",
    },
  },
]

export function BusinessChatArea({ isSidebarCollapsed, onToggleSidebar, className }: BusinessChatAreaProps) {
  const [messages, setMessages] = useState<BusinessMessageType[]>(initialMessages)
  const [isLoading, setIsLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [isVideoActive, setIsVideoActive] = useState(false)
  const [typingUsers, setTypingUsers] = useState<string[]>([])
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const loadMoreMessages = async () => {
    if (isLoading || !hasMore) return
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
  }

  const handleSendMessage = (content: string) => {
    const newMessage: BusinessMessageType = {
      id: `${Date.now()}`,
      user: {
        id: "current",
        name: "You",
        role: "Owner",
        status: "online",
        hasGuardianAngel: true,
      },
      content,
      timestamp: new Date().toLocaleString(),
      type: "text",
    }

    setMessages((prev) => [...prev, newMessage])
  }

  return (
    <div className={cn("flex-1 flex flex-col", className)}>
      {/* Channel Header */}
      <div className="h-14 bg-[#36393f] border-b border-[#202225] flex items-center justify-between px-4">
        <div className="flex items-center space-x-3">
          {/* Mobile/Collapsed Sidebar Toggle */}
          <div className="md:hidden">
            {isSidebarCollapsed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleSidebar}
                className="w-8 h-8 p-0 hover:bg-[#393c43] mr-2"
              >
                <Avatar className="w-6 h-6">
                  <AvatarImage src="/placeholder.svg?height=24&width=24" />
                  <AvatarFallback className="bg-[#5865f2] text-white text-xs">SC</AvatarFallback>
                </Avatar>
              </Button>
            )}
          </div>

          <div className="hidden md:block">
            {isSidebarCollapsed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleSidebar}
                className="w-8 h-8 p-0 hover:bg-[#393c43] mr-2"
              >
                <Menu className="w-4 h-4 text-gray-400" />
              </Button>
            )}
          </div>

          <Hash className="w-5 h-5 text-gray-400" />
          <span className="font-semibold text-white">general</span>
          <Badge variant="outline" className="text-xs text-gray-400 border-gray-600">
            Business Channel
          </Badge>
        </div>

        <div className="flex items-center space-x-3">
          {/* Channel Controls */}
          <div className="flex items-center space-x-1">
            <Button
              variant="ghost"
              size="sm"
              className={cn("w-8 h-8 p-0", isVideoActive ? "bg-green-600 hover:bg-green-700" : "hover:bg-[#393c43]")}
              onClick={() => setIsVideoActive(!isVideoActive)}
            >
              <Video className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
              <Users className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
              <Mic className="w-4 h-4 text-gray-400" />
            </Button>
          </div>

          <ConnectionStatus isConnected={true} onReconnect={() => console.log("Reconnecting...")} />
        </div>
      </div>

      {/* LiveKit Video Overlay */}
      {isVideoActive && (
        <div className="h-48 bg-black border-b border-[#202225] flex items-center justify-center relative">
          <div className="text-white text-center">
            <Video className="w-12 h-12 mx-auto mb-2 text-gray-400" />
            <p className="text-sm">LiveKit Video Session</p>
            <p className="text-xs text-gray-400">Screen sharing and recording available</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2 w-8 h-8 p-0 hover:bg-[#393c43]"
            onClick={() => setIsVideoActive(false)}
          >
            ✕
          </Button>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-hidden">
        <InfiniteScroll
          hasMore={hasMore}
          isLoading={isLoading}
          next={loadMoreMessages}
          threshold={100}
          className="h-full"
        >
          <div className="p-4 space-y-4 min-h-full flex flex-col justify-end">
            {messages.map((message) => (
              <BusinessMessageCard key={message.id} message={message} />
            ))}

            {/* Typing Indicators */}
            {typingUsers.length > 0 && (
              <div className="flex items-center space-x-2 text-gray-400 text-sm">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }} />
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }} />
                </div>
                <span>
                  {typingUsers.join(", ")} {typingUsers.length === 1 ? "is" : "are"} typing...
                </span>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        </InfiniteScroll>
      </div>

      {/* Chat Input */}
      <div className="p-4 bg-[#36393f] border-t border-[#202225]">
        <ChatInput
          placeholder="Message #general - AI Guardian is listening for business context..."
          onSubmit={handleSendMessage}
        />
      </div>
    </div>
  )
}
