"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Settings,
  Hash,
  Volume2,
  Video,
  Mic,
  Headphones,
  Settings2,
  Send,
  Smile,
  PlusCircle,
  Gift,
  Sticker,
  ChevronDown,
  ChevronRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function DiscordInterface() {
  const [expandedSections, setExpandedSections] = useState({
    textChannels: true,
    voiceChannels: true,
    videoChannels: true,
    members: true,
  })

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  return (
    <div className="flex h-screen bg-[#1e2124] text-white">
      {/* Left Sidebar */}
      <div className="w-60 bg-[#2f3136] flex flex-col">
        {/* Server Header */}
        <div className="p-3 border-b border-[#202225] shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback className="bg-[#5865f2] text-white text-xs">KD</AvatarFallback>
              </Avatar>
              <span className="font-semibold text-white">Code with KenDev</span>
            </div>
            <ChevronDown className="w-4 h-4 text-gray-400" />
          </div>
        </div>

        {/* Search */}
        <div className="p-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search"
              className="pl-8 bg-[#202225] border-none text-gray-300 placeholder-gray-500 focus:ring-0 focus:border-none"
            />
            <span className="absolute right-2 top-2 text-xs text-gray-500">CTRL+S</span>
          </div>
        </div>

        {/* Channels */}
        <div className="flex-1 overflow-y-auto">
          {/* Text Channels */}
          <div className="px-2 py-1">
            <button
              onClick={() => toggleSection("textChannels")}
              className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
            >
              <div className="flex items-center space-x-1">
                {expandedSections.textChannels ? (
                  <ChevronDown className="w-3 h-3" />
                ) : (
                  <ChevronRight className="w-3 h-3" />
                )}
                <span>Text Channels</span>
              </div>
              <Plus className="w-4 h-4" />
            </button>

            {expandedSections.textChannels && (
              <div className="mt-1 space-y-0.5">
                <div className="flex items-center space-x-2 px-2 py-1 rounded bg-[#393c43] text-white">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">general</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">links</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">system</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">research</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">news</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Hash className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">youtube</span>
                </div>
              </div>
            )}
          </div>

          {/* Voice Channels */}
          <div className="px-2 py-1 mt-4">
            <button
              onClick={() => toggleSection("voiceChannels")}
              className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
            >
              <div className="flex items-center space-x-1">
                {expandedSections.voiceChannels ? (
                  <ChevronDown className="w-3 h-3" />
                ) : (
                  <ChevronRight className="w-3 h-3" />
                )}
                <span>Voice Channels</span>
              </div>
              <Plus className="w-4 h-4" />
            </button>

            {expandedSections.voiceChannels && (
              <div className="mt-1 space-y-0.5">
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Volume2 className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">Talk Time</span>
                </div>
              </div>
            )}
          </div>

          {/* Video Channels */}
          <div className="px-2 py-1 mt-4">
            <button
              onClick={() => toggleSection("videoChannels")}
              className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
            >
              <div className="flex items-center space-x-1">
                {expandedSections.videoChannels ? (
                  <ChevronDown className="w-3 h-3" />
                ) : (
                  <ChevronRight className="w-3 h-3" />
                )}
                <span>Video Channels</span>
              </div>
              <Plus className="w-4 h-4" />
            </button>

            {expandedSections.videoChannels && (
              <div className="mt-1 space-y-0.5">
                <div className="flex items-center space-x-2 px-2 py-1 rounded hover:bg-[#393c43] text-gray-300 hover:text-white cursor-pointer">
                  <Video className="w-4 h-4 text-gray-400" />
                  <span className="text-sm">Video Channel</span>
                </div>
              </div>
            )}
          </div>

          {/* Members */}
          <div className="px-2 py-1 mt-4">
            <button
              onClick={() => toggleSection("members")}
              className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
            >
              <div className="flex items-center space-x-1">
                {expandedSections.members ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                <span>Members</span>
              </div>
              <Settings className="w-4 h-4" />
            </button>

            {expandedSections.members && (
              <div className="mt-1 space-y-1">
                <div className="flex items-center space-x-2 px-2 py-1">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src="/placeholder.svg?height=24&width=24" />
                    <AvatarFallback className="bg-red-500 text-white text-xs">M</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-gray-300">Manoj Bhuva</span>
                </div>
                <div className="flex items-center space-x-2 px-2 py-1">
                  <Avatar className="w-6 h-6">
                    <AvatarImage src="/placeholder.svg?height=24&width=24" />
                    <AvatarFallback className="bg-blue-500 text-white text-xs">R</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-gray-300">Ren</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* User Panel */}
        <div className="p-2 bg-[#292b2f] border-t border-[#202225]">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Avatar className="w-8 h-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback className="bg-green-500 text-white text-xs">U</AvatarFallback>
              </Avatar>
              <div className="flex flex-col">
                <span className="text-sm font-medium text-white">User</span>
                <span className="text-xs text-gray-400">Online</span>
              </div>
            </div>
            <div className="flex items-center space-x-1">
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
                <Mic className="w-4 h-4 text-gray-400" />
              </Button>
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
                <Headphones className="w-4 h-4 text-gray-400" />
              </Button>
              <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
                <Settings2 className="w-4 h-4 text-gray-400" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Channel Header */}
        <div className="h-12 bg-[#36393f] border-b border-[#202225] flex items-center justify-between px-4">
          <div className="flex items-center space-x-2">
            <Hash className="w-5 h-5 text-gray-400" />
            <span className="font-semibold text-white">general</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <span className="text-sm text-red-400">Disconnected</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Connection lost. Recon...</span>
            </div>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <span className="text-sm">Reconnect</span>
            </Button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Message 1 */}
          <div className="flex space-x-3">
            <Avatar className="w-10 h-10 mt-1">
              <AvatarImage src="/placeholder.svg?height=40&width=40" />
              <AvatarFallback className="bg-blue-500 text-white">KC</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <span className="font-semibold text-white">Kenneth Courtney</span>
                <span className="text-xs text-gray-400">14 Jun 2025, 18:56</span>
              </div>
              <p className="text-gray-300">
                {"Let's try Tavily for BPM Top 20 or 15 or whatever their daily show is Top 15 pretty sure."}
              </p>
            </div>
          </div>

          {/* Message 2 */}
          <div className="flex space-x-3">
            <Avatar className="w-10 h-10 mt-1">
              <AvatarImage src="/placeholder.svg?height=40&width=40" />
              <AvatarFallback className="bg-gray-600 text-white">SU</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-1">
                <span className="font-semibold text-white">System User</span>
                <span className="text-xs text-gray-400">14 Jun 2025, 19:02</span>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className="text-red-400">🎯</span>
                  <span className="font-semibold text-white">Initiating Tavily Search for BPM's Top Tracks</span>
                </div>
                <p className="text-gray-300">
                  Given the current limitations with direct data retrieval, I'll outline a strategic approach to
                  leverage Tavily for identifying BPM's top tracks, focusing on their daily show, which you've indicated
                  is likely the Top 15.
                </p>
                <div className="mt-3">
                  <h3 className="font-semibold text-white mb-2">
                    Strategic Approach to Use Tavily for BPM's Top Tracks:
                  </h3>
                  <div className="pl-4">
                    <span className="text-gray-300">1</span>
                  </div>
                </div>
                <button className="flex items-center space-x-2 text-gray-400 hover:text-white text-sm">
                  <ChevronDown className="w-4 h-4" />
                  <span>Show More (43 more sections)</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Message Input */}
        <div className="p-4 bg-[#36393f]">
          <div className="flex items-center space-x-3 bg-[#40444b] rounded-lg px-4 py-3">
            <PlusCircle className="w-5 h-5 text-gray-400 cursor-pointer hover:text-white" />
            <Input
              placeholder="Message #general (Shift+Enter for new line, paste URLs for research)"
              className="flex-1 bg-transparent border-none text-white placeholder-gray-400 focus:ring-0 focus:border-none"
            />
            <div className="flex items-center space-x-2">
              <Gift className="w-5 h-5 text-gray-400 cursor-pointer hover:text-white" />
              <Sticker className="w-5 h-5 text-gray-400 cursor-pointer hover:text-white" />
              <Smile className="w-5 h-5 text-gray-400 cursor-pointer hover:text-white" />
              <Send className="w-5 h-5 text-gray-400 cursor-pointer hover:text-white" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
